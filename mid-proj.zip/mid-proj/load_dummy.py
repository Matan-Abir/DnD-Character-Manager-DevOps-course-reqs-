"""
Reads /tmp/dummydata/dummy-data.json (downloaded from S3 during docker build)
and inserts every character into the SQLite database.
Runs once at first container start, before the Flask app launches.
"""
import json
import sqlite3
from datetime import datetime

DB_PATH = '/var/db/dnd-app/characters.db'
DUMMY_PATH = '/tmp/dummydata/dummy-data.json'

# Create the table if it doesn't exist yet
conn = sqlite3.connect(DB_PATH)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS characters
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              level INTEGER NOT NULL,
              race TEXT NOT NULL,
              class TEXT NOT NULL,
              stats TEXT NOT NULL,
              inventory TEXT NOT NULL,
              created_at TIMESTAMP)''')
conn.commit()

# Load and insert each character from the JSON file
with open(DUMMY_PATH, 'r') as f:
    characters = json.load(f)

# Handle both a single object and a list
if isinstance(characters, dict):
    characters = [characters]

for char in characters:
    c.execute('''INSERT INTO characters
                 (name, level, race, class, stats, inventory, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
              (
                  char['name'],
                  char['level'],
                  char['race'],
                  char['class'],
                  json.dumps(char['stats']),
                  json.dumps(char['inventory']),
                  datetime.now()
              ))
    print(f"[load_dummy] Inserted: {char['name']}")

conn.commit()
conn.close()
print("[load_dummy] Done.")
