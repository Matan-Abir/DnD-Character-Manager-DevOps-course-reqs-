#!/bin/bash
set -e

APP_DIR=/opt/app/deployment/html/dnd-app
DATA_DIR=/var/db/dnd-app

# Ensure the data directory exists (in case no volume is mounted)
mkdir -p "$DATA_DIR"

# database.py opens sqlite3.connect('characters.db') relative to the
# process's working directory (APP_DIR), NOT DATA_DIR — so on its own,
# the EFS mount at /var/db/dnd-app is never actually used. Symlinking
# the expected filename onto the mounted volume is what makes every
# task's writes land on the same shared EFS file.
ln -sf "$DATA_DIR/characters.db" "$APP_DIR/characters.db"

# On first run: load dummy data from S3 JSON into the SQLite database
# We use the presence of characters.db on EFS as the "already initialised" flag
if [ ! -f "$DATA_DIR/characters.db" ]; then
    if [ -f /tmp/dummydata/dummy-data.json ]; then
        echo "[entrypoint] First run detected — loading S3 dummy data into database..."
        python3 /opt/load_dummy.py
    fi
fi

# Erase dummy data from temp location
if [ -f /tmp/dummydata/dummy-data.json ]; then
    echo "[entrypoint] Removing dummy data from temp location..."
    rm -f /tmp/dummydata/dummy-data.json
fi

echo "[entrypoint] Starting DnD Character Manager on port 80..."
cd "$APP_DIR"
python3 app.py
